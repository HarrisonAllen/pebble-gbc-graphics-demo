This archive contains 4 files:
readme.txt - this file
poke.txt - documentation of the pokemon graphics compression
pokemon.bas - QBasic source code for the decompressor program
pokemon.exe - Executable for the decompressor program


NOTE:
In order for POKEMON.EXE to work, you must have the Gold and Silver roms
in the same directory as this EXE file, and they must be named
"pokeg.gbc" and "pokes.gbc".
Also, your computer must be able to handle QBasic Mode 13.
You can change the screen mode in the .BAS file if you want to see the
pictures in other resolutions/color depths. I'm not sure if it makes any
difference though.
Uncomment the 'savebmp8' lines and the 'savefile$' lines in the source
code if you want to create BMP saves of the images.

Enjoy!
-necrosaro (radimvice@geocities.com)
necrosaro's pokemon page, http://members.aol.com/sabindude/pokemon.html
